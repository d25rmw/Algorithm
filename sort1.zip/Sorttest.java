package sort.mysort;

public class Sorttest {
    public static void main(String[] args) {
        
        int[] numList = {3, 9, 15, 29, 31, 21, 28};

        Sort sort = new Selectionsort();
        sort.setData(numList);
        sort.sort();
    }
}
